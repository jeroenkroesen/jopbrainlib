"""Create and maintain the basis for Artumis Second Brain
"""
