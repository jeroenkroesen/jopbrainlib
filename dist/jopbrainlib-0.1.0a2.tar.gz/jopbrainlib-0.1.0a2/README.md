# jopbrainlib
A python library to enable second brain functionality with the Joplin note app.
