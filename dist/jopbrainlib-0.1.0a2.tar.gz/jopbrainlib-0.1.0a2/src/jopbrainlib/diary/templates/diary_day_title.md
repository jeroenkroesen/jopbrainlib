{{ year }}-{{ month_number }}-{{ day_number }} {{ day_name }} Diary
